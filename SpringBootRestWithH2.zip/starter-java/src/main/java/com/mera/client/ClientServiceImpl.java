package com.mera.client;

import org.springframework.stereotype.Service;

@Service
public class ClientServiceImpl implements ClientService {

}
