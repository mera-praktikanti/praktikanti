package com.mera.presence;

import com.mera.employee.EmployeeEntity;
import lombok.Data;


@Data
public class Presence {
    private int id;
    private String arrival;
    private String departure;
    private String dailyPresence;
    private EmployeeEntity employee;
}
