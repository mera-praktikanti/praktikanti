package com.mera.presence;

import org.springframework.stereotype.Service;

@Service
public class PresenceServiceImpl implements PresenceService {
}
