package com.mera.department;

public interface DepartmentService {
}
