package com.mera.department;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table (name = "department")
public class DepartmentEntity {

    @Id @GeneratedValue
    @Column(name="id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "cfr_department")
    private String CFRDepartment;

    @Column(name = "bu_department")
    private String BUDepartment;

    @Column(name = "reports_to")
    private String reportsTo;

    @Column(name = "program")
    private String program;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn (name = "fk_employee")
    private List<EmployeeEntity> employees;

}
