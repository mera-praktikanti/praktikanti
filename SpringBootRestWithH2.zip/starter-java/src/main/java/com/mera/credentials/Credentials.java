package com.mera.credentials;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

@Data
public class Credentials {
    private int id;
    private String username;
    private String password;
    private EmployeeEntity employee;
}
