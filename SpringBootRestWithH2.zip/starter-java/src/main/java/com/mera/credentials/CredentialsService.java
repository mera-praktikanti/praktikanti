package com.mera.credentials;

public interface CredentialsService {
}
