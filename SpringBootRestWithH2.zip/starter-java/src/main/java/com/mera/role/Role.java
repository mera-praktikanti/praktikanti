package com.mera.role;

import lombok.Data;

@Data
public class Role {
    private int id;
    private String type;
}
