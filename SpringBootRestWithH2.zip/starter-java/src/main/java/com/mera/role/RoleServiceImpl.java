package com.mera.role;

import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {
}
