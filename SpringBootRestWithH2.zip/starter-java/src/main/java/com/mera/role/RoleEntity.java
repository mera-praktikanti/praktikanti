package com.mera.role;


import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "role")
@Data
public class RoleEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "type")
    private String type;
}
