package com.mera.contract.probation;

public interface ProbationService {
}
