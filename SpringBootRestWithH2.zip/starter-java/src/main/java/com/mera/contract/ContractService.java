package com.mera.contract;

public interface ContractService {
}
