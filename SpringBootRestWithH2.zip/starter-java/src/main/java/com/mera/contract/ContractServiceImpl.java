package com.mera.contract;

import org.springframework.stereotype.Service;

@Service
public class ContractServiceImpl implements ContractService {

}
