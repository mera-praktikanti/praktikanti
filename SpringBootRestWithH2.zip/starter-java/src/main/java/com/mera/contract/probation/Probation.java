package com.mera.contract.probation;

import lombok.Data;

@Data
public class Probation {

    private int probationId;

    private String beginDate;

    private String mentor;

    private String registrationDate;
}
