package com.mera.contract;


import com.mera.contract.probation.ProbationEntity;
import com.mera.employee.EmployeeEntity;
import lombok.Data;

import javax.persistence.*;


@Data
@Entity
@Table (name = "contract")
public class ContractEntity {

    @Id @GeneratedValue
    @Column (name = "id")
    private int id;

    @Column(name = "insurance")
    private String insurance;

    @Column(name = "type_of_employment")
    private String typeOfEmployment;

    @Column (name = "agreement_number")
    private String agreementNumber;

    @Column (name = "agreement_date")
    private String agreementDate;

    @Column (name = "time_at_job")
    private String timeAtJob;

    @Column(name = "cost_center")
    private String costCenter;

    @Column(name = "hours_per_week")
    private int hoursPerWeek;

    @OneToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn (name = "fk_employee")
    private EmployeeEntity employeeEntity;

    @OneToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn (name = "fk_probation")
    private ProbationEntity probation;
}
