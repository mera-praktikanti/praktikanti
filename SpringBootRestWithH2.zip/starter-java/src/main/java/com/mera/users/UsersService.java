package com.mera.users;

public interface UsersService {

//    List<UserEntity> getUsersForProvidedRole(String roleName);
}
