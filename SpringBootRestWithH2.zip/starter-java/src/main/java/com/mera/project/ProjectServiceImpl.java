package com.mera.project;

import org.springframework.stereotype.Service;

@Service
public class ProjectServiceImpl implements ProjectService{

}
