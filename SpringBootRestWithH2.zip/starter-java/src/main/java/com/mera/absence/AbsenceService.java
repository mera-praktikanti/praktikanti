package com.mera.absence;

public interface AbsenceService {
}
