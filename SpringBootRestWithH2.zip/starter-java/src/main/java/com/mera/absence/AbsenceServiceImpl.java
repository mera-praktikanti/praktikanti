package com.mera.absence;

import org.springframework.stereotype.Service;

@Service
public class AbsenceServiceImpl implements AbsenceService {
}
