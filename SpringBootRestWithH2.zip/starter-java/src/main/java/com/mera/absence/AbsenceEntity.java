package com.mera.absence;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "absence")
@Data
public class AbsenceEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "absence_start")
    private String absenceStart;
    @Column(name = "absence_end")
    private String absenceEnd;
    @Column(name = "availability")
    private boolean availability;

    @OneToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn(name = "fk_employee")
    private EmployeeEntity employee;
}
