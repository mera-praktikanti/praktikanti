package com.mera.contact.otherContact;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OtherContactRepository extends JpaRepository<OtherContactEntity, Integer> {
}
