package com.mera.contact.phone;

import org.springframework.stereotype.Service;

@Service
public class PhoneServiceImpl implements PhoneService {
}
