package com.mera.contact;

import com.mera.contact.otherContact.OtherContactEntity;
import com.mera.contact.phone.PhoneEntity;
import lombok.Data;

@Data
public class Contact {
    private int id;
    private String location;
    private String email;
    private String officeNumber;
    private PhoneEntity phone;
    private OtherContactEntity otherContact;
}
