package com.mera.contact.otherContact;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "other_contact")
@Data
public class OtherContactEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "icq")
    private String icq;
    @Column(name = "other_email")
    private String otherEmail;
    private String skype;
    @Column(name = "skype_for_bussiness")
    private String skypeForBussiness;
    @Column(name = "other_contacts")
    private String otherContacts;

}
