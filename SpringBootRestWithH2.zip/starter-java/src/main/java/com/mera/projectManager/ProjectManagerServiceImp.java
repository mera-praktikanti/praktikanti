package com.mera.projectManager;

import org.springframework.stereotype.Service;

@Service
public class ProjectManagerServiceImp implements ProjectManagerService {
}


