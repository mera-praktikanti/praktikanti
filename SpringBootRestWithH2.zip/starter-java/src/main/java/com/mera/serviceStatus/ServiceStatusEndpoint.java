package com.mera.serviceStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceStatusEndpoint {
    @Autowired
    ServiceStatusService serviceStatusService;
}
