package com.mera.serviceStatus;

public interface ServiceStatusService {
}
