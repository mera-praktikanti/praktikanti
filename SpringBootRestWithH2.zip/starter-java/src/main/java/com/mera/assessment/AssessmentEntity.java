package com.mera.assessment;

import com.mera.employee.EmployeeEntity;
import com.mera.projectManager.ProjectManagerEntity;
import com.mera.users.UsersEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name = "assessment")
public class AssessmentEntity {

    @Id @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column(name = "last_assessment")
    private String lastAssessment;

    @Column(name = "next_assessment")
    private String nextAssessment;

    @Column (name = "approved_assessment")
    private String approvedAssessment;

    @Column(name = "filled_assessment")
    private String filledAssessment;

    @Column(name = "productivity")
    private String productivity;

    @Column(name = "status")
    private String status;

    @Column(name = "status_changed")
    private String statusChanged;

    @ManyToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn (name = "fk_employee")
    private EmployeeEntity employees;

    @ManyToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn (name = "fk_project_manager")
    private ProjectManagerEntity projectManager;

    @ManyToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn (name = "fk_users")
    private UsersEntity users;
}
