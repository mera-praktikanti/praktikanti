package com.mera.assessment;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AssessmentRepository extends JpaRepository<AssessmentEntity, Integer> {

    @Query(value= "select * from ASSESSMENT join USERS on ASSESSMENT.FK_USERS=USERS.id where USERS.id = :userId", nativeQuery = true)
    AssessmentEntity getLastAssessmentById(@Param("userId")int userId);

    @Query(value= "select * from ASSESSMENT where ASSESSMENT.ID = :userId", nativeQuery = true)
    AssessmentEntity getLastAssessmentByIdTest(@Param("userId")int userId);


}
