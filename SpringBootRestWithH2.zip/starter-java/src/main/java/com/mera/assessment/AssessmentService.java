package com.mera.assessment;

public interface AssessmentService {
    AssessmentEntity getLastAssessment(int userId);
}
