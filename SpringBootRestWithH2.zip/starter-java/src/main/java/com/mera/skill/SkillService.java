package com.mera.skill;

public interface SkillService {
}
