package com.mera.skill;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

import java.util.List;

@Data
public class Skill {
    private int id;
    private String name;
    private char grade;
    private List<EmployeeEntity> employees;
}
