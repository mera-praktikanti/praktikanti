package com.mera.skill;

import org.springframework.stereotype.Service;

@Service
public class SkillServiceImpl implements SkillService {
}
