package com.mera.skill;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "skill")
@Data
public class SkillEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;
    @Column(name = "grade")
    private char grade;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_employee")
    private List<EmployeeEntity> employees;
}
