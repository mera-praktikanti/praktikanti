package com.mera.personalInfo.passport;

import lombok.Data;

@Data
public class Passport {
    private int id;
    private String number;
    private String serie;
    private String issuePlace;
    private String issueDate;
}
