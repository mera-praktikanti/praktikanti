package com.mera.personalInfo.passport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PassportEndpoint {
    @Autowired
    PassportService passportService;
}
