package com.mera.personalInfo.passport;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "passport")
@Data
public class PassportEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "number")
    private String number;
    @Column(name = "serie")
    private String serie;
    @Column(name = "issue_place")
    private String issuePlace;
    @Column(name = "issue_date")
    private String issueDate;
}
