package com.mera.personalInfo.passport;

import org.springframework.stereotype.Service;

@Service
public class PassportServiceImpl implements PassportService {
}
