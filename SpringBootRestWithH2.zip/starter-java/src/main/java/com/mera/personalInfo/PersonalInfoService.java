package com.mera.personalInfo;

public interface PersonalInfoService {
}
