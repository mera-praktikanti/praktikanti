package com.mera.employee;

import com.mera.contact.ContactEntity;
import com.mera.department.DepartmentEntity;
import com.mera.serviceStatus.ServiceStatusEntity;
import com.mera.skill.SkillEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table (name = "employee")
public class EmployeeEntity {

    @Id @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "role")
    private String role;

    @Column(name = "position")
    private String position;

    @Column(name = "position_level")
    private String positionLevel;

    @Column(name = "seniority")
    private String seniority;

    @Column(name ="cv_upload_date")
    private String cvUploadDate;

    @ManyToOne
    @JoinColumn(name = "fk_department")
    private DepartmentEntity department;

    @ManyToMany
    @JoinColumn (name = "fk_project")
    private List<EmployeeEntity> employees;

    @OneToOne(fetch = FetchType.LAZY, optional=false)
    @JoinColumn(name = "fk_contact")
    private ContactEntity contact;

    @ManyToMany
    @JoinColumn(name = "fk_skill")
    private List<SkillEntity> listOfskills;

    @OneToMany (fetch = FetchType.LAZY)
    @JoinColumn (name = "fk_service_status")
    List<ServiceStatusEntity> statusList;
}


