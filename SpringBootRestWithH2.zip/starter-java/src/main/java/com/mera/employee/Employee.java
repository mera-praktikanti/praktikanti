package com.mera.employee;

import com.mera.contact.ContactEntity;
import com.mera.department.DepartmentEntity;
import com.mera.serviceStatus.ServiceStatusEntity;
import com.mera.skill.SkillEntity;
import lombok.Data;

import java.util.List;

@Data
public class Employee {

    private int id;

    private String lastName;

    private String firstName;

    private String role;

    private String position;

    private String positionLevel;

    private String seniority;

    private String cvUploadDate;

    private DepartmentEntity department;

    private ContactEntity contact;

    private List<EmployeeEntity> employees;

    private List<SkillEntity> listOfSkills;

    List<ServiceStatusEntity> statusList;
}
