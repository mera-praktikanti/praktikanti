package com.mera.documents;

import com.mera.users.UsersEntity;
import lombok.Data;


@Data
public class Documents {


    private int id;

    private byte [] cv;

    private UsersEntity usersEntity;
}
