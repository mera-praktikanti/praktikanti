package com.mera.documents;


import com.mera.users.UsersEntity;
import lombok.Data;
import org.springframework.core.io.AbstractResource;

import javax.persistence.*;

@Entity
@Data
@Table(name = "documents")
public class DocumentsEntity {

    @Id @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column (name = "cv")
    private byte [] cv;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "fk_users")
    private UsersEntity usersEntity;




}
