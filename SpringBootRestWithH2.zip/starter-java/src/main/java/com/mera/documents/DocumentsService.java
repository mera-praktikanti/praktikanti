package com.mera.documents;

public interface DocumentsService {

    DocumentsEntity getCv(int userId);
}
