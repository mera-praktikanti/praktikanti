package com.mera.documents;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class DocumentsEndpoint {

    @Autowired
    DocumentsService documentsService;

//        @GetMapping(value = "document/getById", produces = "application/pdf")
//    public ResponseEntity<Resource> returnDocument(@RequestParam int userID) throws IOException, ClassNotFoundException {
//            byte[] documentsEntity = documentsService.getDocument(userID);
//            val headers = new HttpHeaders();
//            headers.add("Content-Disposition", "inline; filename=cv.pdf");;
//
//        return  ResponseEntity.ok()
//                .headers(headers)
//                .contentType(MediaType.APPLICATION_PDF)
//                .body(new ByteArrayResource(documentsEntity));
//
//        }

    @GetMapping(value = "document/getById", produces = "application/pdf")
    public DocumentsEntity returnDocument (@RequestParam int userID) {
        return documentsService.getCv(userID);
    }

//    @GetMapping(value = "document/download", produces = "application/pdf")
//    public byte[] downloadDocument (@RequestParam int userID){
//        return documentsService.getDocument(userID);
//    }

//    @GetMapping(value = "document/getById")
//    public ResponseEntity<InputStreamResource> returnDocument(@RequestParam int userID){
//        val documents = documentsService.getDocument(userID);
//
//        ByteArrayInputStream bis = GeneratePdf.generatePdf(documents);
//        val headers = new HttpHeaders();
//        headers.add("Content-Disposition", "inline; filename=cv.pdf");
//
//        return  ResponseEntity.ok()
//                .headers(headers)
//                .contentType(MediaType.APPLICATION_PDF)
//                .body(new InputStreamResource(bis));
//    }
}
