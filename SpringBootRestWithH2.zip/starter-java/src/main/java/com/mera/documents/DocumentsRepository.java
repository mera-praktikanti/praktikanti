package com.mera.documents;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentsRepository extends JpaRepository<DocumentsEntity, Integer> {

    @Query(value = "select CV from DOCUMENTS JOIN USERS ON DOCUMENTS.FK_USERS = USERS.ID WHERE USERS.Id = :userrId", nativeQuery = true)
    DocumentsEntity getDocumentForUser(@Param("userrId") int userId);


}
