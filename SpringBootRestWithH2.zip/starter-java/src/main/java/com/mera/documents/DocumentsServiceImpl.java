package com.mera.documents;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocumentsServiceImpl implements DocumentsService {

    @Autowired
    DocumentsRepository documentsRepository;

//    @Override
//    public DocumentsEntity getDocument(int userId) {
//        return documentsRepository.getDocumentForUser(userId);
//    }

//    public static Object deserialize(byte[] data) throws IOException, ClassNotFoundException {
//        ByteArrayInputStream in = new ByteArrayInputStream(data);
//        ObjectInputStream is = new ObjectInputStream(in);
//        return is.readObject();

    @Override
    public DocumentsEntity getDocument(int userId) {
        DocumentsEntity documentsEntity = null;
        documentsEntity = documentsRepository.getDocumentForUser(userId);
        byte [] cv =  documentsEntity.getCv();
        return documentsEntity;
    }

}
