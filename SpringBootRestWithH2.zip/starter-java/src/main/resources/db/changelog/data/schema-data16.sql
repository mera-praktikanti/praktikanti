INSERT INTO PROBATION (begin_date, mentor, registration_date) VALUES ('22.06.2016', 'Marko Tomic', '15.06.2016');
INSERT INTO PROBATION (begin_date, mentor, registration_date) VALUES ('02.02.2016', 'Veljko Dimovic', '15.03.2016');
