INSERT INTO PROJECT_MANAGER (last_name, first_name) VALUES ('Nikolic', 'Tamara');
INSERT INTO PROJECT_MANAGER (last_name, first_name) VALUES ('Dimovic', 'Veljko');