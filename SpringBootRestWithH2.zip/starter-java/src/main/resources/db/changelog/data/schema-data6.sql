insert into PERSONAL_INFO(jmbg, birth_date, citizenship, disability) values('1211979805000', '12.11.1979', 'serbian', '-');
insert into PERSONAL_INFO(jmbg, birth_date, citizenship, disability) values('0211979805111', '02.11.1979', 'serbian', '-');
insert into PERSONAL_INFO(jmbg, birth_date, citizenship, disability) values('2211979805222', '22.11.1979', 'serbian', '-');

insert into PASSPORT (number, serie, issue_place, issue_date) values ('907211', '22 06', 'Belgrade', '22.03.2014');
insert into PASSPORT (number, serie, issue_place, issue_date) values ('107542', '22 44', 'Moscow', '22.01.2010');