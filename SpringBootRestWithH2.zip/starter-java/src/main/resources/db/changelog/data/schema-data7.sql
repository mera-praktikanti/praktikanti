insert into SERVICE_STATUS(title, creation_date, status) values ('open port', '03.08.2019', 'closed');
insert into SERVICE_STATUS(title, creation_date, status) values ('account request', '01.08.2019', 'done');
insert into SERVICE_STATUS(title, creation_date, status) values ('open port', '03.07.2019', 'closed')