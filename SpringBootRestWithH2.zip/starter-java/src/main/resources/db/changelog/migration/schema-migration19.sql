CREATE TABLE DOCUMENTS (id serial primary key, cv VARCHAR(100), fk_users int null);
alter table DOCUMENTS
    add constraint DOCUMENTS_USERS__fk
        foreign key (FK_USERS) references USERS (ID);
