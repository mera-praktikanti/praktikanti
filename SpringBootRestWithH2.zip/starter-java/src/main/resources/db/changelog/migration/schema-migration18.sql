alter table USERS
    add constraint USERS_ROLE__fk
        foreign key (FK_ROLE) references ROLE (id);

alter table ABSENCE
    add constraint ABSENCE_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (id);

alter table PRESENCE
    add constraint PRESENCE_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (id);

alter table CONTACT
    add constraint CONTACT_PHONE__fk
        foreign key (FK_PHONE) references PHONE (id);

alter table CONTACT
    add constraint CONTACT_OTHER_CONTACT__fk
        foreign key (FK_OTHER_CONTACT) references OTHER_CONTACT (id);

alter table CREDENTIALS
    add constraint CREDENTIALS_CREDENTIALS__fk
        foreign key (FK_EMPLOYEE) references CREDENTIALS (id);

alter table PERSONAL_INFO
    add constraint PERSONAL_INFO_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table PERSONAL_INFO
    add constraint PERSONAL_INFO_PASSPORT__fk
        foreign key (FK_PASSPORT) references PASSPORT (ID);

alter table SERVICE_STATUS
    add constraint SERVICE_STATUS_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table SKILL
    add constraint SKILL_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table PROJECT
    add constraint PROJECT_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table PROJECT
    add constraint PROJECT_PROJECT_MANAGER__fk
        foreign key (FK_PROJECT_MANAGER) references PROJECT_MANAGER (ID);

alter table EMPLOYEE
    add constraint EMPLOYEE_PROJECT__fk
        foreign key (FK_PROJECT) references PROJECT (ID);

alter table EMPLOYEE
    add constraint EMPLOYEE_CONTACT__fk
        foreign key (FK_CONTACT) references CONTACT (ID);

alter table EMPLOYEE
    add constraint EMPLOYEE_SKILL__fk
        foreign key (FK_SKILL) references SKILL (ID);

alter table DEPARTMENT
    add constraint DEPARTMENT_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table ASSESSMENT
    add constraint ASSESSMENT_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table ASSESSMENT
    add constraint ASSESSMENT_PROJECT_MANAGER__fk
        foreign key (FK_PROJECT_MANAGER) references PROJECT_MANAGER (ID);

alter table ASSESSMENT
    add constraint ASSESSMENT_USERS__fk
        foreign key (FK_USERS) references USERS (id);

alter table CLIENT
    add constraint CLIENT_PROJECT__fk
        foreign key (FK_PROJECT) references PROJECT (ID);

alter table CONTRACT
    add constraint CONTRACT_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table CONTRACT
    add constraint CONTRACT_PROBATION__fk
        foreign key (FK_PROBATION) references PROBATION (ID);

alter table PROJECT_MANAGER
    add constraint PROJECT_MANAGER_EMPLOYEE__fk
        foreign key (FK_EMPLOYEE) references EMPLOYEE (ID);

alter table PROJECT_MANAGER
    add constraint PROJECT_MANAGER_ASSESSMENT__fk
        foreign key (FK_ASSESSMENT) references ASSESSMENT (ID);

