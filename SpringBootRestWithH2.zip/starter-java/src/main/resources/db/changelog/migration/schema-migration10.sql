CREATE TABLE ROLE
(
    id                 serial primary key ,
    type               varchar(30) not null
);