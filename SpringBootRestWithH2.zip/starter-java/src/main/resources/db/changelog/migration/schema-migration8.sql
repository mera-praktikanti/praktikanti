CREATE TABLE SKILL
(
    id          serial primary key ,
    name        varchar(50),
    grade       varchar(1),
    fk_employee int null
);
