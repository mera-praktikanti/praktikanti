CREATE TABLE PERSONAL_INFO
(
    id          serial primary key ,
    jmbg        varchar(13),
    birth_date  varchar(20),
    citizenship varchar(50),
    disability  varchar(50),
    fk_employee int null,
    fk_passport int null
);
CREATE TABLE PASSPORT
(
    id          serial primary key ,
    number      varchar(50),
    serie       varchar(50),
    issue_place varchar(50),
    issue_date  varchar(20)
);