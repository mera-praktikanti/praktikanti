CREATE TABLE CLIENT
(
    id         serial primary key ,
    name       varchar(50) not null,
    fk_project int         null
);