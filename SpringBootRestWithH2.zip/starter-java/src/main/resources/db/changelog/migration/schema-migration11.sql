CREATE TABLE EMPLOYEE
(
    id                serial primary key ,
    last_name         varchar(25) not null,
    first_name        varchar(25) not null,
    role              varchar(25),
    position          varchar(25),
    position_level    varchar(25),
    seniority         varchar(25),
    cv_upload         varchar(20),
    fk_project        int         null,
    fk_contact        int         null,
    fk_skill          int         null
);