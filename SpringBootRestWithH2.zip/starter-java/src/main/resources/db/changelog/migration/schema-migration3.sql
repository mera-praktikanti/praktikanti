CREATE TABLE PRESENCE
(
    id             serial primary key ,
    arrival        varchar(20),
    departure      varchar(20),
    daily_presence varchar(20),
    fk_employee    int null
);
