CREATE TABLE ASSESSMENT
(
    id                  serial primary key ,
    last_assessment     varchar(30),
    next_assessment     varchar(30),
    approved_assessment varchar(30),
    filled_assessment   varchar(20),
    productivity        varchar(25),
    status              varchar(25),
    status_changed      varchar(20),
    fk_employee         int null,
    fk_project_manager  int null,
    fk_users            int null
);