CREATE TABLE USERS
(
    id         serial PRIMARY KEY ,
    first_name varchar(50),
    last_name  varchar(50),
    email      varchar(50),
    password   varchar(50),
    fk_role    int null

);


