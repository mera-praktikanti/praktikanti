# starter-java
For starting any new app

Spring boot application

That can be used as starting point for any other future project. 

  Included:
    SpringBoot
    Lombok
    Swagger
    Liquibase
    H2 - can be used as embedded(jdbc:h2:file:C:/baza/embed;MODE=PostgreSQL) or in memorry (jdbc:h2:mem:baza;MODE=PostgreSQL)
